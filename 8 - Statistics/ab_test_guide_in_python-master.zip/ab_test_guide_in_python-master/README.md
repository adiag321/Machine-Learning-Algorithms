#A/B testing: A step-by-step guide in Python
This is a walkthrough of how to design and analyse an A/B test using Python. It is probably more useful to researchers rather than engineers.
